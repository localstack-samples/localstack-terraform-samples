def handler(event, context):
    return {"message": "Successfully executed"}
