def handler(event, context):
    raise Exception("No value present")
